package models;

import java.util.List;

public class StudentsDto {
	public List<Student> students;
	
}
